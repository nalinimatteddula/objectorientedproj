package oopproj;

public class JuniorSavingsAccount extends SavingsAccount {

	String guardianName;

	public JuniorSavingsAccount(int accNo, float balance, int pin, String guardianName) {
		super(accNo, balance, pin);
		this.guardianName = guardianName;
	}
	
	public void getDetails() {
		System.out.println("AccountNo: "+accNo);
	     // System.out.println("Balance :"+balance();
	     // System.out.println("pin :"+pin);
	      System.out.println("guardianName "+guardianName);     
	}
	
	
	public void withdrawAmount(int pin, int withdrawalAmount) {
		if(this.pin== pin) {
			if (withdrawalAmount <=1000) {
				
				withdrawAmount(withdrawalAmount);
			}
			else {
				System.out.println("Limit exceeded");
			}
			
		}else 
			System.out.println("invalid pin");
	}
	
}

