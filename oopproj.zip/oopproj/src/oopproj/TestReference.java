package oopproj;

public class TestReference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
