package oopproj;

import java.time.LocalDate;

public class Employee {
     
	int id;
	String name;
	String email;
	Gender gender;
	LocalDate dob;
	String phone;
	public Employee() {
		
	}
	public Employee(int id, String name, String email, Gender gender, LocalDate dob, String phone) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.dob = dob;
		this.phone = phone;
	}
	
	public void calcualteSalary() {
		
	}
}
