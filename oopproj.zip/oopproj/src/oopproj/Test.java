package oopproj;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		SavingsAccount account = new SavingsAccount(101,2000,45);
		
		
		System.out.println("Account No :"+account.accNo);
		System.out.println("balance  :"+account.balance);
		System.out.println("pin  :"+account.pin);
		System.out.println("MinBal  :"+SavingsAccount.minBalance);
		SavingsAccount.minBalance=1000;
		
        SavingsAccount account2 = new SavingsAccount(102,10000,123456);
         account2.deposit(500);
		
        System.out.println();
		//account2.accNo =102;
		//account2.balance=10000;
		//account2.pin=123456;
		System.out.println("Account No :"+account2.accNo);
		System.out.println("balance  :"+account2.balance);
		System.out.println("pin  :"+account2.pin);
		System.out.println("MinBal  :"+SavingsAccount.minBalance);
		account2.deposit(500);

		 SavingsAccount account3 = new SavingsAccount(1,200,12);
		 SavingsAccount.minBalance=3000;
		 account3.deposit(200);
			
	        System.out.println();
	        
			System.out.println("Account No :"+account3.accNo);
			System.out.println("balance  :"+account3.balance);
			System.out.println("pin  :"+account3.pin);
			System.out.println("MinBal  :"+SavingsAccount.minBalance);
	}

}
