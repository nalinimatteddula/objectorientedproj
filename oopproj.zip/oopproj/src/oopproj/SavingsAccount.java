package oopproj;

public class SavingsAccount {
   
	 int accNo;
	 float balance;
	
	//public float getBalance() {
		//return balance;
	//}

	 int pin;
	static int minBalance =100;
	//default constructor
	public SavingsAccount() {
		// TODO Auto-generated constructor stub
	}
	
	//parameterized constructor
	public SavingsAccount(int accNo, float balance, int pin) {
		this.accNo = accNo;
		this.balance = balance;
		this.pin = pin;
	}
	
	public boolean isPinValid(int pin) {
		if(this.pin==pin) {
			return true;
		}
		return false;
	}
	
	public static int getminBalance()
	{
		return minBalance;
	}

	public void deposit(int amount){
		if(amount > 0) {
			balance = balance + amount;
		}else 
			System.out.println("Invalid deposit Amount");
	}
    
	public void withdrawAmount(int withdraw) {
		if (withdraw <=balance) {
			balance = balance - withdraw;
					
		}else 
			System.out.println("insufficient funds");
	}
	public void printDetails() {
		System.out.println("Account Details:"+accNo+"Balance :"+balance);
	}
	
	public void withdrawAmount(int pin, int withdrawalAmount) {
		if(this.pin== pin) {
			if (withdrawalAmount <=4000) {
				
				withdrawAmount(withdrawalAmount);
			}
			else {
				System.out.println("Limit exceeded");
			}
			
		}else 
			System.out.println("invalid pin");
	}
	
	
	}



