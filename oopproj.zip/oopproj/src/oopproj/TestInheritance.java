package oopproj;

public class TestInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
      JuniorSavingsAccount account = new JuniorSavingsAccount(101, 5000, 1234, "nalini");
      account.withdrawAmount(2000);
     // System.out.println("AccountNo: "+account.accNo);
     // System.out.println("Balance :"+account.balance);
     // System.out.println("pin :"+account.pin);
     // System.out.println("guardianName "+account.guardianName);
      account.getDetails();
      account.withdrawAmount(1234, 2000);
      
	}

}
