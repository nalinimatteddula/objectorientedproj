package oopproj;

public enum Gender {
	Male,female,other

}
