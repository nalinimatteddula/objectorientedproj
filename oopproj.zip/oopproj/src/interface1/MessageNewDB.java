package interface1;

public class MessageNewDB {
	
	public String fetchNewDBMessage() {
		return "NewDB: Interfaces, Try me!";
	}

}
