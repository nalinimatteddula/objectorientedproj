package interface1;

public class TestMessagePrinter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MessagePrinter messagePrinter = new MessagePrinter();
		messagePrinter.printMessage("file");

	}

}
