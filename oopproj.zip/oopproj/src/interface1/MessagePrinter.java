package interface1;

public class MessagePrinter {
	
	private MessageDB messageDB;
	private MessageFile messageFile;
	private MessageNewDB messageNewDB;
	
	public MessagePrinter() {
		messageDB = new MessageDB();
		messageFile = new MessageFile();
		messageNewDB = new MessageNewDB();
		}

	public void printMessage(String sourceName) {
		if(sourceName.equals("db")) {
			System.out.println(messageDB.fetchDBMessage());
		
		}else if(sourceName.equals("file")) {
			System.out.println(messageFile.fetchFileMessage());
		}else if(sourceName.equals("newdb")) {
			System.out.println(messageNewDB.fetchNewDBMessage());
		
	}
		}
}
