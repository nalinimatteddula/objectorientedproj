package interface1;

//Developer A
public class MessageDB {
	
	public String fetchDBMessage() {
		return "DB Message: Welcome to the world of interface";
	}

}
