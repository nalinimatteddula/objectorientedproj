package interface1;

public class MessageFile {

	public String fetchFileMessage() {
		return "File Message :Interfaces play a key role";
	}
}
